

<?php $__env->startSection('content'); ?>

<style>
    .img-container .image-wrapper {
    height: 150px; /* Set a fixed height for consistent display */
    overflow: hidden;
}

.img-container .image-wrapper img {
    object-fit: cover;
    max-height: 100%;
    max-width: 100%;
}

    </style>

<div class="CM-main-content">
    <div class="container-fluid p-0">
        <div class="campaign-card-contents">
            <div class="col-lg-12 p-0">
                <div class="card">
                    <div class="heading_text">
                        <div class="title_status">
                            <h3><?php echo e($campaign->name); ?></h3>
                            <p class="status <?php echo e($campaign->is_active ? 'green' : 'red'); ?>">
                                <?php echo e($campaign->is_active ? 'Active' : 'Inactive'); ?>

                            </p>
                                                    </div>
                        <p><?php echo e($campaign->description); ?></p>
                    </div>
                    <!-- campaign-cost-task -->
                    
                    <!-- campaign-cost-task -->
                    <!-- Owl carousel -->
                    

                    <div class="row d-flex justify-content-center">
                        <div class="col-lg-9 col-md-10 col-sm-10 p-0">
                            <div class="owl-carousel owl-theme">
                                <div class="item py-3">
                                    <a href="#">
                                        <div class="card-img_text">
                                            <div class="Detail-card-image">
                                                <img src="<?php echo e(asset('assets/images/automated-prompt-generation-with-generative-ai 1.png')); ?>"
                                                    alt="automated-prompt-generation">
                                            </div>
                                            <div class="crew-mark cross">
                                                <svg width="12" height="12" viewBox="0 0 12 12" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.369 0.234884C1.05582 -0.0782947 0.548061 -0.0782947 0.234883 0.234884C-0.0782944 0.548063 -0.0782944 1.05583 0.234883 1.36901L4.86588 6.00002L0.234931 10.631C-0.0782463 10.9442 -0.0782466 11.4519 0.234931 11.7651C0.548109 12.0783 1.05587 12.0783 1.36905 11.7651L6 7.13415L10.631 11.7651C10.9441 12.0783 11.4519 12.0783 11.7651 11.7651C12.0782 11.4519 12.0782 10.9442 11.7651 10.631L7.13412 6.00002L11.7651 1.36901C12.0783 1.05583 12.0783 0.548063 11.7651 0.234884C11.4519 -0.0782947 10.9442 -0.0782947 10.631 0.234884L6 4.8659L1.369 0.234884Z"
                                                        fill="black" />
                                                </svg>

                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="item py-3">
                                    <a href="#">
                                        <div class="card-img_text">
                                            <div class="Detail-card-image">
                                                <img src="<?php echo e(asset('assets/images/autumn-forest-lake-landscape 1.png')); ?>"
                                                    alt="assets/images/autumn-forest">
                                            </div>
                                            <div class="crew-mark cross">
                                                <svg width="12" height="12" viewBox="0 0 12 12" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.369 0.234884C1.05582 -0.0782947 0.548061 -0.0782947 0.234883 0.234884C-0.0782944 0.548063 -0.0782944 1.05583 0.234883 1.36901L4.86588 6.00002L0.234931 10.631C-0.0782463 10.9442 -0.0782466 11.4519 0.234931 11.7651C0.548109 12.0783 1.05587 12.0783 1.36905 11.7651L6 7.13415L10.631 11.7651C10.9441 12.0783 11.4519 12.0783 11.7651 11.7651C12.0782 11.4519 12.0782 10.9442 11.7651 10.631L7.13412 6.00002L11.7651 1.36901C12.0783 1.05583 12.0783 0.548063 11.7651 0.234884C11.4519 -0.0782947 10.9442 -0.0782947 10.631 0.234884L6 4.8659L1.369 0.234884Z"
                                                        fill="black" />
                                                </svg>

                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="item py-3">
                                    <a href="#">
                                        <div class="card-img_text">
                                            <div class="Detail-card-image">
                                                <img src="<?php echo e(asset('assets/images/cascade-boat-clean-china-natural-rural 1.png')); ?>"
                                                    alt="cascade-boat-clean">
                                            </div>
                                            <div class="crew-mark cross">
                                                <svg width="12" height="12" viewBox="0 0 12 12" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M1.369 0.234884C1.05582 -0.0782947 0.548061 -0.0782947 0.234883 0.234884C-0.0782944 0.548063 -0.0782944 1.05583 0.234883 1.36901L4.86588 6.00002L0.234931 10.631C-0.0782463 10.9442 -0.0782466 11.4519 0.234931 11.7651C0.548109 12.0783 1.05587 12.0783 1.36905 11.7651L6 7.13415L10.631 11.7651C10.9441 12.0783 11.4519 12.0783 11.7651 11.7651C12.0782 11.4519 12.0782 10.9442 11.7651 10.631L7.13412 6.00002L11.7651 1.36901C12.0783 1.05583 12.0783 0.548063 11.7651 0.234884C11.4519 -0.0782947 10.9442 -0.0782947 10.631 0.234884L6 4.8659L1.369 0.234884Z"
                                                        fill="black" />
                                                </svg>

                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- owl carousel -->
                    <!-- Table -->
                    <div class="campaigns-title">
                        <h3><?php echo e($campaign->name); ?> - TASKS</h3>
                    </div>
                    <div class="campaingn-table common-table">
                        <div class="table-wrapper">
                            <table>
                                <thead>
                                    <tr>

                                        <th class="campaingn-title">
                                            <span>Task Title</span>
                                        </th>
                                        <th>
                                            <span>Campaign</span>
                                        </th>
                                        <th>
                                            <span>Due Date</span>
                                        </th>
                                        <th class="description">
                                            <span>description</span>
                                        </th>
                                        <th class="">
                                            <span>active</span>
                                        </th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="campaingn-title">
                                            <span><?php echo e($task->name); ?></span>
                                        </td>
                                        <td>
                                            <span><?php echo e($campaign->name); ?></span>
                                        </td>
                                        <td>
                                            <span><?php echo e($task->date_required); ?></span>
                                        </td>
                                        <td class="description">
                                            <span><?php echo e($task->description); ?>

                                            </span>
                                        </td>
                                        <td class="">
                                            <span><?php echo e(optional($task->status)->name ?? 'No Status'); ?></span>
                                        </td>
                                        
                                            
                                                
                                                
                                                        

                                                
                                            
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- Table -->
                </div>
            </div>
        </div>
        <!-- Pagination -->
        <div class="card-pagination">

        </div>
        <!-- Pagination -->
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pap\resources\views/campaigns/show.blade.php ENDPATH**/ ?>