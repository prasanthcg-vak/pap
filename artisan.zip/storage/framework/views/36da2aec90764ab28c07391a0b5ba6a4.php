    <!-- resources/views/clientpartner/create.blade.php -->
    

    <?php $__env->startSection('content'); ?>
        <div class="CM-main-content">
            <div class="container-fluid p-0">
                <!-- profile-content -->
                <div class="profile-content add-a-partner">
                    <div class="profile-header">
                        <h3>ADD A PARTNER</h3>
                    </div>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('clientpartner.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <!-- Partner Name -->
                                <div class="profile-con">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <p class="profile-label">Partner Name:</p>
                                        </div>
                                        <div class="col-sm-8">
                                            <input type="text" name="partner_name" id="partner_name"
                                                placeholder="Partner Name" required value="<?php echo e(old('partner_name')); ?>">
                                            <?php $__errorArgs = ['partner_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Partner Contact -->
                                <div class="profile-con">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <p class="profile-label">Partner Contact:</p>
                                        </div>
                                        <div class="col-sm-8">
                                            <input type="text" name="partner_contact" id="partner_contact"
                                                placeholder="Partner Contact" required value="<?php echo e(old('partner_contact')); ?>">
                                            <?php $__errorArgs = ['partner_contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Email -->
                                <div class="profile-con">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <p class="profile-label">Email:</p>
                                        </div>
                                        <div class="col-sm-8">
                                            <input type="email" name="partner_email" id="partner_email"
                                                placeholder="Partner Email" required value="<?php echo e(old('partner_email')); ?>">
                                            <?php $__errorArgs = ['partner_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="profile-con">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <p class="profile-label">Client Group:</p>
                                        </div>
                                        <div class="col-sm-8">

                                            <select name="group" class="form-select  common-select" id="group_id">
                                                <option value="">Select Group</option>
                                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['partner_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <!-- Status -->
                                <div class="profile-con add-partner-status">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <p class="profile-label">Status:</p>
                                        </div>
                                        <div class="col-sm-8">
                                            <div>
                                                <input type="radio" id="active" name="status" value="active"
                                                    <?php echo e(old('status') == 'active' ? 'checked' : ''); ?>>
                                                <label for="active">Active</label><br>
                                                <input type="radio" id="inactive" name="status" value="inactive"
                                                    <?php echo e(old('status') == 'inactive' ? 'checked' : ''); ?>>
                                                <label for="inactive">Inactive</label><br>
                                            </div>
                                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <!-- Partner Logo -->
                                <div class="profile-con">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <p class="profile-label">Partner Logo:</p>
                                        </div>
                                        <div class="col-sm-8">
                                            <div class="additional-img">
                                                <div class="upload--col">
                                                    <div class="drop-zone">
                                                        <div class="drop-zone__prompt">
                                                            <div class="drop-zone_color-txt">
                                                                <span><img src="<?php echo e(asset('assets/images/Image.png')); ?>"
                                                                        alt=""></span> <br>
                                                                <span><img
                                                                        src="<?php echo e(asset('assets/images/fi_upload-cloud.svg')); ?>"
                                                                        alt=""> Upload Image</span>
                                                            </div>
                                                        </div>
                                                        <input type="file" name="logo" class="drop-zone__input">
                                                    </div>
                                                </div>


                                            </div>
                                            <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <div class="submit-button text-end">
                                                <button type="submit" class="btn submit-btn">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- profile-content -->
            </div>
        </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pap\resources\views/clientpartner/create.blade.php ENDPATH**/ ?>