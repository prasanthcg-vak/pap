<?php $__env->startSection('content'); ?>
<div class="CM-main-content">
    <div class="container-fluid p-0">
        <!-- Table -->
        <div class="task campaingn-table pb-3 common-table">
            <!-- campaigns-contents -->
            <div class="col-lg-12 task campaigns-contents">
                <div class="campaigns-title">
                    <h3>Assign Permissions to Role: <?php echo e($role->name); ?></h3>
                </div>
            </div>
            <!-- campaigns-contents -->
        </div>
        <form action="<?php echo e(route('roles.permissions.update', $role->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="accordion" id="permissionsAccordion">
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $groupPermissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="heading-<?php echo e($group); ?>">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo e($group); ?>" aria-expanded="true" aria-controls="collapse-<?php echo e($group); ?>">
                            <?php echo e($group); ?>

                        </button>
                    </h2>
                    <div id="collapse-<?php echo e($group); ?>" class="accordion-collapse collapse show" aria-labelledby="heading-<?php echo e($group); ?>" data-bs-parent="#permissionsAccordion">
                        <div class="accordion-body">
                            <?php $__currentLoopData = $groupPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>" id="permission-<?php echo e($permission->id); ?>"
                                    <?php echo e($role->permissions->contains($permission->id) ? 'checked' : ''); ?> >
                                    <label class="form-check-label" for="permission-<?php echo e($permission->id); ?>">
                                        <?php echo e($permission->label); ?>

                                    </label>
                                    <!-- <small class="text-muted"><?php echo e($permission->description); ?></small> -->
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button type="submit" class="common-btn mt-3"><i class="fa-solid fa-floppy-disk"></i> Submit</button>
        <a type="button" class="cancel-btn my-4" href="<?php echo e(route('roles.index')); ?>">
                <i class="fas fa-ban"></i>
                Cancel
            </a>
    </form>
    </div>
</div>
<div class="container">
    
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pap\resources\views/role-permissions/edit.blade.php ENDPATH**/ ?>