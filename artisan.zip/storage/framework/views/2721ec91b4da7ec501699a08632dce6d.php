

<?php $__env->startSection('content'); ?>
    <div class="CM-main-content">
        <div class="container-fluid p-0">
            <!-- profile-content -->
            <div class="profile-content add-a-partner">
                <div class="profile-header">
                    <h3>Edit Partner</h3>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <form action="<?php echo e(route('clientpartner.update', $clientPartner->id)); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="profile-con">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <p class="profile-label">Partner Name:</p>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="text" name="partner_name" id="partner_name"
                                            value="<?php echo e(old('partner_name', $clientPartner->name)); ?>"
                                            placeholder="Partner Name" required>
                                        <?php $__errorArgs = ['partner_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="profile-con">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <p class="profile-label">Partner Contact:</p>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="text" name="partner_contact" id="partner_contact"
                                            value="<?php echo e(old('partner_contact', $clientPartner->contact)); ?>"
                                            placeholder="Partner Contact" required>
                                        <?php $__errorArgs = ['partner_contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="profile-con">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <p class="profile-label">Email:</p>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="email" name="partner_email" id="partner_email"
                                            value="<?php echo e(old('partner_email', $clientPartner->email)); ?>"
                                            placeholder="Partner Email" required>
                                        <?php $__errorArgs = ['partner_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="profile-con">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <p class="profile-label">Client Group:</p>
                                    </div>
                                    <div class="col-sm-8">

                                        <select name="group" class="form-select  common-select" id="group_id">
                                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($group->id); ?>" <?php echo e($group->id = $group_id ? 'selected':''); ?>><?php echo e($group->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['partner_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="text-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="profile-con add-partner-status">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <p class="profile-label">Status:</p>
                                    </div>
                                    <div class="col-sm-8">
                                        <input type="radio" id="active" name="status" value="active"
                                            <?php echo e(old('status', $clientPartner->is_active) == 1 ? 'checked' : ''); ?>>
                                        <label for="active">Active</label><br>
                                        <input type="radio" id="inactive" name="status" value="inactive"
                                            <?php echo e(old('status', $clientPartner->is_active) == 0 ? 'checked' : ''); ?>>
                                        <label for="inactive">Inactive</label><br>
                                    </div>
                                </div>
                            </div>
                            <div class="profile-con">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <p class="profile-label">Partner Logo:</p>
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="additional-img">
                                            <div class="upload--col">
                                                <div class="drop-zone">
                                                    <div class="drop-zone__prompt">
                                                        <div class="drop-zone_color-txt">
                                                            <?php if($clientPartner->profile_picture): ?>
                                                                <img src="<?php echo e(asset($clientPartner->profile_picture)); ?>"
                                                                    alt="Partner Logo" style="width: 100px; height: 100px;">
                                                            <?php else: ?>
                                                                <span><img src="assets/images/Image.png"
                                                                        alt=""></span> <br>
                                                            <?php endif; ?>
                                                            <span><img src="assets/images/fi_upload-cloud.svg"
                                                                    alt=""> Upload Image</span>
                                                        </div>
                                                    </div>
                                                    <input type="file" name="logo" class="drop-zone__input">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="submit-button text-end">
                                <button type="submit" class="btn submit-btn">Update Partner</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- profile-content -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pap\resources\views/clientpartner/edit.blade.php ENDPATH**/ ?>