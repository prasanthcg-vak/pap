<!DOCTYPE html>
<html>
<head>
    <title>Your Account Password</title>
</head>
<body>
    <h1>Hello,</h1>
    <p>Welcome to our platform. Here is your password:</p>
    <p><strong>Password:</strong> <?php echo e($password); ?></p>
    <p>Please change your password after logging in.</p>
    <p>Best Regards,<br>Your Company</p>
</body>
</html>
<?php /**PATH C:\laragon\www\pap\resources\views/emails/password.blade.php ENDPATH**/ ?>