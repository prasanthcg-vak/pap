<!-- resources/views/groups/show.blade.php -->
<h1>{{ $group->client_group_name }}</h1>
<p>Created at: {{ $group->created_at }}</p>
